#' Fire data
#'
"fire"
